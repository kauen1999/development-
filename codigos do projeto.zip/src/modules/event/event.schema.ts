// src/modules/event/event.schema.ts
import { z } from "zod";

// Auto seat generation structure
const generateSeatsSchema = z.object({
  rows: z.array(z.string().min(1)).min(1),
  seatsPerRow: z.number().int().min(1),
});

// Ticket category schema
const ticketTypeSchema = z.object({
  title: z.string().min(1),
  price: z.number().min(0),
  stock: z.number().int().min(1),
  generateSeats: generateSeatsSchema.optional(),
});

// Conversor de string para Date
const dateStringToDate = z.preprocess((val) => new Date(val as string), z.date());

// Create event schema
export const createEventSchema = z.object({
  name: z.string().min(1), // atualizado de title para name
  description: z.string().min(1),
  location: z.string().min(1),
  date: dateStringToDate,
  saleStart: dateStringToDate,
  saleEnd: dateStringToDate,
  city: z.string().min(1),
  theater: z.string().min(1),
  slug: z.string().min(1),
  price: z.number().min(0),
  capacity: z.number().int().min(1),
  userId: z.string().cuid(),
  categoryIds: z.array(z.string().cuid()).min(1),
  ticketCategories: z.array(ticketTypeSchema).min(1),
  status: z.enum(["DRAFT", "PUBLISHED", "CANCELLED"]).optional(),
  publishedAt: z.date().optional(),
});

// Update event schema
export const updateEventSchema = createEventSchema.partial().extend({
  id: z.string().cuid(),
});

// Get event by ID schema
export const getEventByIdSchema = z.object({
  id: z.string().cuid(),
});
