// src/pages/login.tsx
import LoginSection from "@/components/principal/login/LoginSection";
export default function LoginPage() { return <LoginSection />; }
