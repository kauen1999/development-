// src/pages/register.tsx
import RegisterSection from "@/components/principal/register/RegisterSection";

export default function RegisterPage() { return <RegisterSection />; }
