// src/pages/event/create.tsx
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { createEventSchema } from "@/modules/event/event.schema";
import type { z } from "zod";
import { trpc } from "@/utils/trpc";
import { useRouter } from "next/router";
import { useSession } from "next-auth/react";
import type { FieldError, UseFormRegisterReturn } from "react-hook-form";

type CreateEventInput = z.infer<typeof createEventSchema>;
const CATEGORY_ID = "cmdt510590000iabptnrsobd4"; // ✅ ID real do banco

export default function CreateEventPage() {
  const router = useRouter();
  const { data: session } = useSession();
  const [ticketTypes, setTicketTypes] = useState<CreateEventInput["ticketCategories"]>([
    { title: "Pista", price: 50, stock: 100 },
  ]);

  const mutation = trpc.event.create.useMutation({
    onSuccess: () => router.push("/dashboard"),
    onError: (err) => {
      if (err.message.includes("Unique constraint failed on the fields: (`name`)")) {
        alert("Já existe um evento com esse nome. Escolha outro.");
      } else if (err.message.includes("Unique constraint failed on the fields: (`slug`)")) {
        alert("Já existe um evento com esse slug. Tente outro.");
      } else {
        console.error("❌ Erro ao criar evento:", err);
        alert("Erro ao criar evento: " + err.message);
      }
    },
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<CreateEventInput>({
    resolver: zodResolver(createEventSchema),
  });

  const onSubmit = (data: CreateEventInput) => {
    if (!session?.user?.id) {
      alert("Usuário não autenticado");
      return;
    }

    mutation.mutate({
      ...data,
      userId: session.user.id,
      categoryIds: [CATEGORY_ID],
      ticketCategories: ticketTypes,
      status: "PUBLISHED",
      publishedAt: new Date(),
    });
  };

  const createRandomEvent = () => {
    if (!session?.user?.id) return alert("Usuário não autenticado");

    const now = new Date();
    const random = Math.floor(Math.random() * 1000000);

    mutation.mutate({
      name: `Evento Teste ${random}`,
      description: "Criado automaticamente",
      location: `Local ${random}`,
      date: new Date(now.getTime() + 3600000),
      saleStart: now,
      saleEnd: new Date(now.getTime() + 86400000),
      city: `Cidade ${random}`,
      theater: `Teatro ${random}`,
      slug: `evento-auto-${random}`,
      price: 99,
      capacity: 300,
      userId: session.user.id,
      categoryIds: [CATEGORY_ID],
      ticketCategories: [
        { title: "VIP", price: 150, stock: 50 },
        { title: "Pista", price: 99, stock: 250 },
      ],
      status: "PUBLISHED",
      publishedAt: new Date(),
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 px-4 py-10">
      <div className="mx-auto w-full max-w-2xl rounded-lg bg-white p-6 shadow-md">
        <h1 className="mb-6 text-2xl font-bold text-gray-800">Criar Evento</h1>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <Input label="Nome do Evento" name="name" register={register("name")} error={errors.name} />
          <Input label="Descrição" name="description" register={register("description")} error={errors.description} />
          <Input label="Slug" name="slug" register={register("slug")} error={errors.slug} />
          <Input label="Local" name="location" register={register("location")} error={errors.location} />
          <Input label="Cidade" name="city" register={register("city")} error={errors.city} />
          <Input label="Teatro" name="theater" register={register("theater")} error={errors.theater} />
          <Input label="Data do evento" name="date" type="date" register={register("date")} error={errors.date} />
          <Input label="Início das vendas" name="saleStart" type="date" register={register("saleStart")} error={errors.saleStart} />
          <Input label="Fim das vendas" name="saleEnd" type="date" register={register("saleEnd")} error={errors.saleEnd} />
          <Input label="Preço base" name="price" type="number" register={register("price", { valueAsNumber: true })} error={errors.price} />
          <Input label="Capacidade" name="capacity" type="number" register={register("capacity", { valueAsNumber: true })} error={errors.capacity} />

          <div>
            <p className="mb-2 font-medium text-gray-700">Categorias de Ingressos</p>
            {ticketTypes.map((ticket, i) => (
              <div key={i} className="mb-4 flex flex-col gap-2 rounded border border-gray-200 p-4">
                <div className="grid grid-cols-3 gap-2">
                  <input
                    type="text"
                    placeholder="Nome"
                    className="rounded border border-gray-300 px-2 py-1"
                    value={ticket.title}
                    onChange={(e) =>
                      setTicketTypes((prev) =>
                        prev.map((t, index) =>
                          index === i ? { ...t, title: e.target.value } : t
                        )
                      )
                    }
                  />
                  <input
                    type="number"
                    placeholder="Preço"
                    className="rounded border border-gray-300 px-2 py-1"
                    value={ticket.price}
                    onChange={(e) =>
                      setTicketTypes((prev) =>
                        prev.map((t, index) =>
                          index === i ? { ...t, price: Number(e.target.value) } : t
                        )
                      )
                    }
                  />
                  <input
                    type="number"
                    placeholder="Estoque"
                    className="rounded border border-gray-300 px-2 py-1"
                    value={ticket.stock}
                    onChange={(e) =>
                      setTicketTypes((prev) =>
                        prev.map((t, index) =>
                          index === i ? { ...t, stock: Number(e.target.value) } : t
                        )
                      )
                    }
                  />
                </div>
                <button
                  type="button"
                  onClick={() => setTicketTypes((prev) => prev.filter((_, index) => index !== i))}
                  className="self-end text-sm text-red-600 hover:underline"
                >
                  Remover
                </button>
              </div>
            ))}
            <button
              type="button"
              onClick={() => setTicketTypes((prev) => [...prev, { title: "", price: 0, stock: 0 }])}
              className="mt-2 rounded bg-primary-100 px-4 py-2 text-sm font-semibold text-white hover:bg-primary-200"
            >
              + Adicionar Categoria
            </button>
          </div>

          <div className="flex justify-end gap-4">
            <button
              type="submit"
              className="rounded-lg bg-primary-100 px-6 py-2 font-semibold text-white transition hover:bg-primary-200"
            >
              Criar e Publicar
            </button>
            <button
              type="button"
              onClick={createRandomEvent}
              className="rounded-lg bg-green-600 px-6 py-2 font-semibold text-white transition hover:bg-green-700"
            >
              Testar Envio 🚀
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

interface InputProps {
  label: string;
  name: keyof CreateEventInput;
  type?: "text" | "number" | "date";
  register: UseFormRegisterReturn;
  error?: FieldError;
}

const Input = ({ label, type = "text", register, error }: InputProps) => (
  <div>
    <label className="mb-1 block text-sm font-medium text-gray-700">{label}</label>
    <input
      {...register}
      type={type}
      className="w-full rounded-lg border border-gray-300 px-3 py-2"
    />
    {error && <p className="text-sm text-red-600">{error.message}</p>}
  </div>
);
