-- AlterTable
ALTER TABLE "Event" ADD COLUMN     "publishedAt" TIMESTAMP(3);
