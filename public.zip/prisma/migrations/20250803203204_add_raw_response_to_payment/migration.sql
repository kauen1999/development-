-- AlterTable
ALTER TABLE "Payment" ADD COLUMN     "rawResponse" JSONB;
