-- AlterTable
ALTER TABLE "CartItem" ADD COLUMN     "expiresAt" TIMESTAMP(3);
