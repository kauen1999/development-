-- AlterTable
ALTER TABLE "CartItem" ADD COLUMN     "eventId" TEXT;
