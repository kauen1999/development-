// src/pages/api/webhooks/pagotic.ts
import type { NextApiRequest, NextApiResponse } from "next";
import { prisma } from "@/lib/prisma";
import { generateTicketsFromOrder } from "@/modules/ticket/ticket.service";
import { sendTicketEmail } from "@/modules/sendmail/mailer";
import type { Ticket } from "@prisma/client";

// Aceita até 1mb
export const config = { api: { bodyParser: { sizeLimit: "1mb" } } };

// Helpers
function toStr(v: unknown): string | undefined {
  if (typeof v === "string") return v;
  if (typeof v === "number" && Number.isFinite(v)) return String(v);
  return undefined;
}

function resolveOrderIdFromExternal(externalId: string): string {
  if (!externalId.toLowerCase().startsWith("order_")) return externalId;
  return externalId.slice(6);
}

type PagoTicNotification = {
  id?: string;
  status?: string;
  final_amount?: number;
  currency?: string;
  collector?: string;
  external_transaction_id?: string;
  metadata?: unknown;
  payment_number?: string | number | null;
};

function normalizeOrderStatus(
  statusRaw: string | undefined
): "PAID" | "PENDING" | "CANCELLED" {
  const s = (statusRaw ?? "").trim().toLowerCase();
  const approved = new Set([
    "approved",
    "accredited",
    "paid",
    "aprobado",
    "pagado",
  ]);
  if (approved.has(s)) return "PAID";
  const cancelled = new Set(["rejected", "cancelled", "canceled"]);
  if (cancelled.has(s)) return "CANCELLED";
  return "PENDING";
}

function parseNotification(req: NextApiRequest): PagoTicNotification {
  const ct = String(req.headers["content-type"] ?? "");
  if (ct.includes("application/x-www-form-urlencoded")) {
    const raw = req.body as Record<string, unknown>;
    return {
      id: toStr(raw.id),
      status: toStr(raw.status),
      final_amount:
        typeof raw.final_amount === "string"
          ? Number(raw.final_amount)
          : (raw.final_amount as number | undefined),
      currency: toStr(raw.currency),
      collector: toStr(raw.collector),
      external_transaction_id: toStr(raw.external_transaction_id),
      payment_number: raw.payment_number as
        | string
        | number
        | null
        | undefined,
      metadata: raw.metadata,
    };
  }
  return req.body as PagoTicNotification;
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // 🔹 Log inicial sempre
  console.log("[PAGOTIC][Webhook] Incoming request:", {
    method: req.method,
    headers: req.headers,
    body: req.body,
  });

  // 🔹 Aceitar POST (padrão) e GET (fallback para debug)
  if (req.method !== "POST") {
    console.warn(
      "[PAGOTIC][Webhook] Método inesperado:",
      req.method,
      "→ respondendo 200 para evitar retry storm"
    );
    return res.status(200).json({ ok: true, method: req.method });
  }

  try {
    const body = parseNotification(req);

    // Guard opcional por collector
    if (process.env.PAGOTIC_COLLECTOR_ID) {
      const collector = toStr(body.collector);
      if (collector && collector !== process.env.PAGOTIC_COLLECTOR_ID) {
        console.warn("[PagoTIC][Webhook] Collector inválido:", {
          got: collector,
          expected: process.env.PAGOTIC_COLLECTOR_ID,
        });
        return res.status(200).json({ ok: true });
      }
    }

    const ext = toStr(body.external_transaction_id);
    if (!ext) {
      console.error(
        "[PagoTIC][Webhook] external_transaction_id ausente no payload"
      );
      return res.status(200).json({ ok: true });
    }

    const orderId = resolveOrderIdFromExternal(ext);
    const nextStatus = normalizeOrderStatus(body.status);
    const paymentId = toStr(body.id);

    console.log("[PAGOTIC][Webhook] Parsed data:", {
      orderId,
      status: body.status,
      normalized: nextStatus,
      paymentId,
    });

    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { user: true, event: true },
    });
    if (!order) {
      console.error("[PagoTIC][Webhook] Order não encontrada:", orderId);
      return res.status(200).json({ ok: true });
    }

    if (order.status === "PAID" && nextStatus === "PAID") {
      console.log(
        "[PAGOTIC][Webhook] Order já estava paga, ignorando:",
        orderId
      );
      return res.status(200).json({ ok: true, message: "Already PAID" });
    }

    const updated = await prisma.order.update({
      where: { id: orderId },
      data: {
        status: nextStatus,
        externalTransactionId: ext,
        paymentNumber: paymentId ?? order.paymentNumber,
      },
      include: { user: true, event: true },
    });

    console.log("[PAGOTIC][Webhook] Order atualizada:", {
      id: updated.id,
      status: updated.status,
    });

    if (nextStatus === "PAID") {
      try {
        const ticketsRaw = await generateTicketsFromOrder(updated.id);
        const tickets = (ticketsRaw as Array<Ticket | null>).filter(
          (t): t is Ticket => !!t
        );
        console.log(
          "[PAGOTIC][Webhook] Tickets gerados:",
          tickets.map((t) => t.id)
        );

        if (updated.user?.email) {
          await sendTicketEmail(updated.user, updated.event, tickets);
          console.log(
            "[PAGOTIC][Webhook] E-mail enviado para:",
            updated.user.email
          );
        }
      } catch (e) {
        console.error(
          "[PagoTIC][Webhook] Pós-pagamento falhou:",
          (e as Error).message
        );
      }
    }

    return res.status(200).json({ ok: true });
  } catch (e) {
    console.error("[PagoTIC][Webhook] Erro:", (e as Error).message);
    return res.status(200).json({ ok: true });
  }
}
