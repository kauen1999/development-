// src/pages/api/auth/register.ts
import { registerHandler } from "@/modules/auth/controller";
export default registerHandler;
