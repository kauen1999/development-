// src/pages/api/auth/complete-profile.ts
import { completeProfileHandler } from "@/modules/auth/controller";
export default completeProfileHandler;
