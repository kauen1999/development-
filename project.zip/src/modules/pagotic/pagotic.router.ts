// src/moduls/pagotic/pagotic.router.ts
import { router, protectedProcedure, publicProcedure } from "@/server/trpc/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  cancelPaymentInput,
  createPaymentInput,
  distributionInput,
  getPaymentByIdInput,
  groupPaymentsInput,
  listPaymentsInput,
  refundInput,
} from "./pagotic.schema";
import { PagoticService } from "./pagotic.service";
import { mapPayment } from "./pagotic.mappers";
import { prisma } from "@/lib/prisma";

const svc = new PagoticService();

// --- helpers locais (sem alterar o service) ---
function isPublicHttpUrl(value?: string): value is string {
  if (!value) return false;
  try {
    const u = new URL(value);
    const isHttp = u.protocol === "http:" || u.protocol === "https:";
    const isLocalhost =
      u.hostname === "localhost" ||
      u.hostname === "127.0.0.1" ||
      u.hostname.endsWith(".local");
    return isHttp && !isLocalhost;
  } catch {
    return false;
  }
}

// normaliza URLs vindas do client: ""/localhost/ inválida -> undefined
function normalizeInputUrl(v?: string): string | undefined {
  return isPublicHttpUrl(v) ? v : undefined;
}

// Extrai orderId que você injeta no ctx (quando existir)
function extractOrderId(ctx: unknown): string | undefined {
  if (ctx && typeof ctx === "object" && "orderId" in ctx) {
    const val = (ctx as { orderId?: unknown }).orderId;
    return typeof val === "string" ? val : undefined;
  }
  return undefined;
}

export const pagoticRouter = router({
  // === Usado no frontend: busca formUrl/paymentId já criados ===
  startPagoTICPayment: protectedProcedure
    .input(z.object({ orderId: z.string().min(1) }))
    .mutation(async ({ input, ctx }) => {
      const order = await prisma.order.findUnique({
        where: { id: input.orderId },
        select: { id: true, userId: true, formUrl: true, paymentNumber: true, status: true },
      });
      if (!order) throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });

      const userId = ctx.session?.user?.id;
      if (userId && order.userId !== userId) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Not allowed" });
      }

      if (!order.paymentNumber || !order.formUrl) {
        throw new TRPCError({
          code: "PRECONDITION_FAILED",
          message: "Order has no payment prepared. Create order first.",
        });
      }

      return {
        orderId: order.id,
        paymentId: order.paymentNumber,
        formUrl: order.formUrl,
        checkoutUrl: order.formUrl,
        status: order.status,
      };
    }),

  createPayment: protectedProcedure
    .input(createPaymentInput)
    .mutation(async ({ input, ctx }) => {
      // 1) Garantimos um orderId consistente (ctx > metadata > external_transaction_id)
      const orderIdFromCtx = extractOrderId(ctx);
      const orderIdFromMeta =
        typeof input.metadata?.appOrderId === "string" && input.metadata.appOrderId
          ? input.metadata.appOrderId
          : undefined;
      const orderIdFromExt =
        typeof input.external_transaction_id === "string" && input.external_transaction_id
          ? input.external_transaction_id.replace(/^order_/i, "")
          : undefined;

      const orderId = orderIdFromCtx ?? orderIdFromMeta ?? orderIdFromExt;
      if (!orderId) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Missing order id to build external_transaction_id",
        });
      }

      // 2) Limpeza das URLs vindas do client; se ficar undefined, o service usará .env
      const cleaned = {
        ...input,
        external_transaction_id: `order_${orderId}`,
        return_url: normalizeInputUrl(input.return_url),
        back_url: normalizeInputUrl(input.back_url),
        notification_url: normalizeInputUrl(input.notification_url),
        metadata: {
          ...(input.metadata ?? {}),
          appOrderId: orderId,
          appUserId: ctx.session?.user?.id ?? undefined,
        },
      };

      // 3) Chama o service (ele completa com .env quando os campos acima estão undefined)
      const resp = await svc.createPayment(cleaned);
      const mapped = mapPayment(resp);

      // 4) Persistimos na Order para o fluxo (importante para startPagoTICPayment/retornos)
      try {
        await prisma.order.update({
          where: { id: orderId },
          data: {
            paymentNumber: mapped.id,      // id real do PagoTIC
            formUrl: mapped.formUrl ?? null,
            externalTransactionId: `order_${orderId}`,
            // status permanece o atual — quem muda para PAID será o webhook
          },
        });
      } catch (e) {
        // Não bloqueia o retorno ao cliente, mas registra
        console.error("[PagoTIC][router.createPayment] Falha ao espelhar na Order:", (e as Error).message);
      }

      return mapped;
    }),

  getPaymentById: protectedProcedure
    .input(getPaymentByIdInput)
    .query(async ({ input }) => {
      const resp = await svc.getPaymentById(input.id);
      return mapPayment(resp);
    }),

  listPayments: protectedProcedure
    .input(listPaymentsInput)
    .query(async ({ input }) => {
      const resp = await svc.listPayments({
        page: input.page,
        limit: input.limit,
        filters: input.filters,
        sorts: input.sorts,
      });
      return {
        ...resp,
        data: resp.data.map(mapPayment),
      };
    }),

  cancelPayment: protectedProcedure
    .input(cancelPaymentInput)
    .mutation(async ({ input }) => {
      const resp = await svc.cancelPayment(input.id, input.status_detail);
      return mapPayment(resp);
    }),

  refundPayment: protectedProcedure
    .input(refundInput)
    .mutation(async ({ input }) => {
      const { id, ...rest } = input;
      return svc.refundPayment(id, rest);
    }),

  groupPayments: protectedProcedure
    .input(groupPaymentsInput)
    .mutation(async ({ input }) => {
      return svc.groupPayments({ paymentIds: input.paymentIds });
    }),

  ungroupPayments: protectedProcedure
    .input(z.object({ groupId: z.string().min(1) }))
    .mutation(async ({ input }) => {
      return svc.ungroupPayments(input.groupId);
    }),

  distributePayment: protectedProcedure
    .input(distributionInput)
    .mutation(async ({ input }) => {
      return svc.distributePayment(input);
    }),

  resendNotification: publicProcedure
    .input(getPaymentByIdInput)
    .mutation(async ({ input }) => {
      return svc.resendNotification(input.id);
    }),
});
