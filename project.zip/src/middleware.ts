import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { getToken } from "next-auth/jwt";
import type { JWT } from "next-auth/jwt";

// Rotas públicas (não exigem autenticação)
const PUBLIC_PATHS = [
  "/login",
  "/register",
  "/favicon.ico",
  "/_next",
  "/.well-known",
  "/auth",
  "/api/trpc/auth.register",
  "/api/trpc/event.list",
  "/api/trpc/event.listByDate",
  "/api/trpc/event.getById",
];

// Rotas protegidas (exigem login + perfil completo)
const PROTECTED_PATHS = ["/checkout", "/pagamento", "/buydetails"];

function isPublic(pathname: string) {
  return PUBLIC_PATHS.some((p) => pathname === p || pathname.startsWith(p));
}

function isProtected(pathname: string) {
  return PROTECTED_PATHS.some((p) => pathname.startsWith(p));
}

// Nosso JWT com o campo extra
type AppJWT = JWT & { profileCompleted?: boolean };

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Ignora rotas internas do NextAuth
  if (pathname.startsWith("/api/auth")) return NextResponse.next();

  // Ignora todos os webhooks (sempre públicos)
  if (pathname.startsWith("/api/webhooks")) return NextResponse.next();

  // Libera caminhos públicos
  if (isPublic(pathname)) return NextResponse.next();

  const raw = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  const token = raw as AppJWT | null;

  if (!token) {
    const url = new URL("/login", req.url);
    url.searchParams.set("callbackUrl", req.nextUrl.pathname);
    return NextResponse.redirect(url);
  }

  if (isProtected(pathname)) {
    const profileCompleted = Boolean(token.profileCompleted);
    if (!profileCompleted) {
      const redirectUrl = new URL("/auth", req.url);
      redirectUrl.searchParams.set("redirect", pathname);
      return NextResponse.redirect(redirectUrl);
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/((?!api/auth|api/webhooks|_next/static|_next/image|favicon.ico|.well-known).*)",
  ],
};
