import type { NextAuthOptions, User } from "next-auth";
import type { Provider } from "next-auth/providers";
import Credentials from "next-auth/providers/credentials";
import GoogleProvider from "next-auth/providers/google";

// Strongly-typed API response
type LoginResponse = {
  ok: boolean;
  user?: {
    id: string;
    name?: string;
    email?: string;
    image?: string;
    role?: "ADMIN" | "USER";
    profileCompleted?: boolean;
  };
  message?: string;
};

// Calls your backend to authenticate with email/password
async function loginWithApi(email: string, password: string): Promise<User | null> {
  console.info("[auth] loginWithApi:start", { email });

  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    console.debug("[auth] loginWithApi:status", res.status);

    if (!res.ok) {
      const text = await res.text().catch(() => "");
      console.warn("[auth] loginWithApi:response_not_ok", { status: res.status, text });
      return null;
    }

    const data: unknown = await res.json();
    console.debug("[auth] loginWithApi:json", data);

    // Safe narrowing
    const parsed = data as LoginResponse;
    if (!parsed.ok || !parsed.user) {
      console.warn("[auth] loginWithApi:invalid_payload", parsed);
      return null;
    }

    const u = parsed.user;
    const user: User = {
      id: u.id,
      name: u.name ?? null,
      email: u.email ?? null,
      image: u.image ?? null,
      // estes campos assumem augmentation de tipos (ver nota no fim)
      role: u.role ?? "USER",
      profileCompleted: Boolean(u.profileCompleted),
    };

    console.info("[auth] loginWithApi:success", {
      id: user.id,
      role: user.role,
      profileCompleted: user.profileCompleted,
    });

    return user;
  } catch (err: unknown) {
    console.error("[auth] loginWithApi:error", err);
    return null;
  }
}

// Read Google creds safely (no non-null assertions)
const googleClientId = process.env.GOOGLE_CLIENT_ID;
const googleClientSecret = process.env.GOOGLE_CLIENT_SECRET;

// Build providers as Provider[] to avoid TS2345 when pushing GoogleProvider
function getProviders(): Provider[] {
  const list: Provider[] = [
    Credentials({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      // Correct signature: (credentials, req?) — omit req to evitar unused var
      async authorize(
        credentials?: Record<"email" | "password", string>
      ): Promise<User | null> {
        console.info("[auth] credentials.authorize:called");

        if (!credentials?.email || !credentials?.password) {
          console.warn("[auth] credentials.authorize:missing_fields");
          return null;
        }

        const user = await loginWithApi(credentials.email, credentials.password);
        console.info("[auth] credentials.authorize:result", { hasUser: Boolean(user) });
        return user; // must be User | null
      },
    }),
  ];

  if (googleClientId && googleClientSecret) {
    list.push(
      GoogleProvider({
        clientId: googleClientId,
        clientSecret: googleClientSecret,
      })
    );
  } else {
    console.warn("[auth] Google provider disabled: missing GOOGLE_CLIENT_ID/GOOGLE_CLIENT_SECRET");
  }

  return list;
}

export const authOptions: NextAuthOptions = {
  providers: getProviders(),
  callbacks: {
    async jwt({ token, user, account }) {
      console.debug("[auth] jwt:called", { hasUser: Boolean(user), provider: account?.provider });

      if (user) {
        // Persist custom fields from User into the token
        token.id = user.id;
        token.role = user.role;
        token.profileCompleted = user.profileCompleted;
      }
      return token;
    },
    async session({ session, token }) {
      console.debug("[auth] session:called", {
        email: session.user?.email,
        tokenRole: token.role,
        tokenProfileCompleted: token.profileCompleted,
      });

      // Derive safe locals without `any`
      const id = typeof token.id === "string" ? token.id : "";
      const role = (token.role as "ADMIN" | "USER" | undefined) ?? undefined;
      const profileCompleted = Boolean(token.profileCompleted);

      session.user = {
        ...session.user,
        id,
        role,
        profileCompleted,
      };

      console.info("[auth] session:result", {
        id,
        role,
        profileCompleted,
      });

      return session;
    },
    async redirect({ url, baseUrl }) {
      console.debug("[auth] redirect:called", { url, baseUrl });
      if (url.startsWith("/")) return `${baseUrl}${url}`;
      if (new URL(url).origin === baseUrl) return url;
      return baseUrl;
    },
  },
  pages: {
    signIn: "/login",
  },
  // Centralize errors/warnings/debug (substitui events.error)
  logger: {
    error(code, metadata) {
      console.error("[auth] logger:error", { code, metadata });
    },
    warn(code) {
      console.warn("[auth] logger:warn", code);
    },
    debug(code, metadata) {
      console.debug("[auth] logger:debug", { code, metadata });
    },
  },
  debug: process.env.NODE_ENV === "development",
};
